<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rrestaurantuser extends Model
{
    protected $table = "restaurant_user";
}
