<?php

function ar()
{
    return 'ar';
}